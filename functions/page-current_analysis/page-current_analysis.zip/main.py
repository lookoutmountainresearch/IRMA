
def page_current_analysis(data, context):
    print(data)
    print(context)
    return
